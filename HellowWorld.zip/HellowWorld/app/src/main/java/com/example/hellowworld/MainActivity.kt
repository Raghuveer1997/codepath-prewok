package com.example.hellowworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.button).setOnClickListener {
            //handle button tap
            //2. change the color of the text
            Log.i("Raghuveer", "Tapped on button")
            //Get a reference to the text view
            findViewById<TextView>(R.id.textView).setTextColor(getResources().getColor(R.color.purple_200))

        }

    }
}
